package de.fhpotsdam.generics;

import de.fhpotsdam.unfolding.marker.Marker;

public class ClassHavingMarkerManager {

	MarkerManager<? extends Marker> markerManager;
	
//	public void addMarker(Marker marker) {
//		markerManager.addMarker(marker);
//	}

}
