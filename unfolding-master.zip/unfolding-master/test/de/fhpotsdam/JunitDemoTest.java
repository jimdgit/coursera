package de.fhpotsdam;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class JunitDemoTest {

	@Test
	public void testIfJunitWorks() {
		// just make sure JUnit works :)
		assertTrue(true);
	}
}
