resources can be loaded from the EMF editor using URIs:

pathmap://MYPATHMAP/UMLModelWithoutCustomProfile.emx
pathmap://MYPATHMAP/MyLibModel.uml